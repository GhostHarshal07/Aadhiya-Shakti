AADHIYA SHAKTI ACADEMY - SETUP ON WINDOWS WITH XAMPP
=====================================================

This copy is already configured for XAMPP's default settings:
  MySQL host 127.0.0.1, port 3306, user root, password (empty)
  Database name: aadhiya_shakti_site

1. Install XAMPP (https://www.apachefriends.org) - default folder C:\xampp
2. Open "XAMPP Control Panel" and click Start for Apache and MySQL (both turn green).
3. Copy the folder "aadhiya-shakti" into C:\xampp\htdocs\
      -> C:\xampp\htdocs\aadhiya-shakti\index.php must exist
4. Open http://localhost/phpmyadmin
      - If a database "aadhiya_shakti_site" already exists, open it -> Operations -> Drop the database.
      - Click "Import" -> Choose File -> aadhiya-shakti\database\full-setup.sql -> Import (Go).
      - You should see 9 tables in aadhiya_shakti_site.
5. Website:     http://localhost/aadhiya-shakti/
6. Admin panel: http://localhost/aadhiya-shakti/admin/login.php
      username: admin    password: ChangeMe123!
      Change the password from "My Password" after first login.

TROUBLESHOOTING
- "Access denied for user root": you set a MySQL password -> put it in includes\config.php (DB_PASS).
- MySQL will not start (port 3306 busy): XAMPP Config -> my.ini -> change port=3307,
  then set DB_PORT to 3307 in includes\config.php.
- Apache will not start (port 80 busy, often Skype/IIS): Apache Config -> httpd.conf ->
  change "Listen 80" to "Listen 8080", then open http://localhost:8080/aadhiya-shakti/
- "Unknown database": step 4 import was not done.
- Uploaded images not saving: make sure assets\images\uploads exists (it is included).

NO PAYMENT SYSTEM IS IMPLEMENTED.
