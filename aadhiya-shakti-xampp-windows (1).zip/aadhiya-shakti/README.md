# Aadhiya Shakti Academy — Static Frontend Site

## Admin Portal Enhancement (latest)

**NO PAYMENT SYSTEM WAS IMPLEMENTED.** Prices are display text only.

### Setup / upgrade (MAMP, phpMyAdmin)
Import in this order into database `aadhiya_shakti_site` (skip any you already imported):
1. `database/schema.sql`  2. `database/admin-features.sql`  3. `database/courses-management.sql`  4. `database/tutors-and-roles.sql`
Then log in at `admin/login.php` (admin / ChangeMe123!) and open `database/migrate.php` **once**. It adds the new admin_users columns, makes every existing admin a Super Admin, and copies the built-in categories, 32 courses and 10 demo instructors into the database so they become editable. Nothing is deleted; re-running is safe.

### What the admin can do
| Page | Path | Permission |
|---|---|---|
| Dashboard (courses / tutors / admins / enquiries / recent activity) | `admin/index.php` | any admin |
| Courses: add, edit, delete, activate, image upload + preview, search & filters | `admin/courses.php`, `course-edit.php` | manage_courses (+ manage_course_images for the image) |
| Categories & subcategories | `admin/categories.php` | manage_categories |
| Tutors: add, edit, delete, image upload + preview, social links | `admin/tutors.php`, `tutor-edit.php` | manage_tutors (+ manage_tutor_images) |
| Admin members, roles, custom permissions, activate/deactivate, reset password | `admin/members.php`, `member-edit.php` | manage_admins |
| Activity log | `admin/activity.php` | manage_admins |
| Messages / Site photos / My password | existing pages | manage_messages / manage_photos / any |

Roles: Super Admin (everything), Admin, Content Manager, Course Manager, Tutor Manager. The member form pre-fills permissions from the role, and you can tick/untick boxes to customise. Permissions are checked **on the server for every page and every POST** (`admin_require_permission()` in `includes/config.php`); hiding menu items is only cosmetic.

Safety rules: you cannot deactivate/delete yourself or the last active Super Admin; deactivated admins cannot log in and are signed out on their next request; deleting a tutor who teaches courses forces you to pick a replacement tutor (or "no tutor") first.

Uploads: real image check (`getimagesize`), JPG/PNG/WEBP/GIF only, max 5 MB, random server-side filename, stored in `assets/images/uploads/`, old file removed on replace.

### Logout
`admin/logout.php` records the logout, destroys the session, expires the cookie and redirects to the **public homepage** `index.php`. Admin pages then redirect to `admin/login.php`.


## New: Full admin panel (course pricing, photos, messages, multiple admin logins)

The admin panel now does four things, each tested end-to-end against a real database before delivery:

1. **View Contact form submissions** (`admin/messages.php`)
2. **Edit course prices** (`admin/courses.php`) — changes appear instantly on the public Courses and Course Detail pages
3. **Upload replacement photos** (`admin/media.php`) — for the Dance/Singing/Choreography category cards and the About page photo, straight from your computer
4. **Manage admin accounts** — more than one person can have their own login (see "Adding an admin account" below)

An "Admin" link now sits in the site's top navigation, next to "Contact Us", on every page.

### Setup (MAMP)

1. Start MAMP, open phpMyAdmin.
2. Create a database named `aadhiya_shakti_site` (collation `utf8mb4_general_ci`) if you haven't already.
3. Import **both** SQL files, in this order:
   - `database/schema.sql` (creates `contact_messages`)
   - `database/admin-features.sql` (creates `admin_users`, `course_overrides`, `site_images`, and a starter admin login)
4. `includes/config.php` is pre-set for MAMP's defaults (`127.0.0.1`, port `8889`, `root`/`root`).

### Logging in

Visit `admin/index.php` or click "Admin" in the nav. Starter login:
```
Username: admin
Password: ChangeMe123!
```
**Change this password immediately** via Admin → Password once logged in.

### How the database connects to the admin panel

`includes/config.php` defines a `db()` function that opens one shared PDO (PHP Data Objects) connection to MySQL. Every admin page calls `db()` when it needs to read or write — for example, `admin/courses.php` runs an `INSERT ... ON DUPLICATE KEY UPDATE` query to save a price change into the `course_overrides` table. The public pages (`courses.php`, `course-detail.php`, `index.php`, `about.php`) then call functions in `includes/data.php` like `get_courses()` and `get_site_image()`, which check those override tables and use an admin's saved changes instead of the default value — falling back to the original static content automatically if the database isn't reachable, so the public site never breaks just because MySQL is down.

### Adding an admin account (do this in phpMyAdmin, not through the site — there's no public signup page, which is intentional)

1. **Generate a password hash.** In Terminal:
   ```
   php -r "echo password_hash('TheNewPersonsPassword', PASSWORD_DEFAULT);"
   ```
   Copy the full output (starts with `$2y$10$...`).
2. In phpMyAdmin, open the `aadhiya_shakti_site` database → `admin_users` table → click **Insert**.
3. Fill in:
   - `username`: whatever login name they'll use
   - `password_hash`: paste the hash from step 1 (**not** the plain password — never type the plain password into this field)
   - Leave `id` and `created_at` blank/auto
4. Click **Go**. That person can now log in at `admin/login.php` with their username and the password you generated the hash from.

### What "rights" the admin has, and why

- **Messages**: view/filter/mark-read/archive/delete — because someone needs to actually act on enquiries.
- **Course pricing**: edit any course's price — because pricing is the thing site owners change most often and shouldn't require editing PHP code for.
- **Photos**: replace specific named photos — scoped to four spots (three category cards + About), not open file-system access, so an admin can't accidentally overwrite unrelated files.
- **Password management**: change their own password — every account should be able to rotate its own credentials without needing a developer.
- Deliberately **not** included: editing course descriptions/instructors/full content, or managing other admins' accounts through the UI. Those still go through code/phpMyAdmin by design, to keep the blast radius of the admin panel small and auditable.

### Security notes

- Every upload is validated by actually reading the file's contents (`getimagesize()`), not trusting the filename or extension — a `.jpg` that's secretly something else is rejected.
- Uploaded files are renamed to a random, safe filename server-side; the original filename is never used to write to disk.
- All admin forms use CSRF tokens and prepared statements.
- Passwords are never stored in plain text, only as bcrypt hashes.

---

## Recent visual update

- **Logo**: your uploaded artwork is now used as the site logo in the nav, footer, and favicon (`assets/images/logo.png`). It had a near-white (not truly transparent) background baked in, so it's been processed to remove that and crop tightly to the artwork.
- **Color palette**: fully replaced with `#601D49` (deep plum), `#BD5579` (rose), `#EA9D9D` (blush), and `#FFEBB8` (cream) — every CSS variable in `assets/css/style.css` now maps to these. Body text uses darker shades derived from the plum tone for readability, since pure hot-pink text at length is hard to read.
- **Instructor images**: all 10 instructors now have a genuinely unique photo — none share an image with each other (verified programmatically before delivery).
- **Hero cursor glow**: move your mouse over the homepage hero section — a soft rose/blush glow follows the cursor (`assets/js/main.js`, respects `prefers-reduced-motion`).
- **Scroll parallax**: the hero image shifts slightly as you scroll past it, and the header gains a subtle shadow once you scroll down.
- **Mirror/reflection effect**: a faded, flipped reflection sits beneath the hero image, like a polished floor.
- **Varied scroll-reveal**: homepage sections now animate in from different directions (fade-up, fade-left, fade-right, scale-in) instead of one repeated effect.
- **Contact page locations**: a highlighted "Service Areas" panel on the left of the Contact page lists Jamnagar, Ahmedabad, Vadodara, Surat, Rajkot, and Online (All India) — labeled as service areas, not confirmed physical branches, per the project's honesty rules.

**A note on testing**: I couldn't get a pixel-perfect screenshot of the final result from my end, because my testing sandbox's network only permits a small allowlist of developer domains and Unsplash's image CDN isn't on it. I confirmed instead that every image URL was legitimately sourced (via a page fetch tool that isn't subject to that restriction), that hotlinking these URLs is Unsplash's own documented, supported way to embed their photos, and that every other part of the update — PHP syntax, page routing, unique instructor images, CSS/JS wiring — passed direct testing. Take a look once you open it locally, and let me know if anything looks off.

A mostly-static website — no MySQL, no login system for visitors, and no
admin panel for managing course content — with one deliberate exception:
the Contact page now saves submissions to MySQL, with a small
password-protected admin page to view them. See "New: Contact form +
admin panel" above for that part; everything below describes the rest
of the site, which remains exactly as originally built.

## Running the rest of the site (no database needed for these pages)

Every page except Contact works exactly as before, no setup required.

1. Extract the project.
2. Open the folder in VS Code (or any editor).
3. From inside the project folder, start PHP's built-in server:
   ```
   php -S localhost:8000
   ```
4. Open `http://localhost:8000` in your browser.

That's it — everything works immediately, with no configuration.

## Editing content

Every piece of content on the site — courses, instructors, testimonials,
gallery items, events, FAQs, category structure — lives in one file:
**`includes/data.php`**. Open it and edit the PHP arrays directly. No page
template needs to change when you add or edit a course; every page reads
from these same functions (`get_courses()`, `get_instructors()`, etc.).

## Important notes on content honesty

This project follows a strict "no invented business facts" rule throughout:

- **Instructor names**: the original brief for this project asked to use
  several real, well-known public figures' names as instructor profiles.
  Those have been **replaced with fictional names** instead. Presenting
  real celebrities as instructors at a fictional academy — even labeled
  "demo" — risks implying a real-world affiliation that doesn't exist.
  Every instructor profile is clearly marked **"Demo Instructor"** on the
  page itself.
- **Establishment year, city, address, phone, email, social links**: all
  shown as `[TO BE CONFIRMED]` placeholders rather than invented facts.
  Search-and-replace these in `includes/footer.php`, `about.php`, and
  `contact.php` once real details are available.
- **Testimonials**: clearly labeled "Sample Testimonials" throughout —
  written for this project, not real customer reviews.
- **Pricing**: labeled "Sample Pricing" or "Starting From" — not
  presented as final, verified pricing.

## Images

A small set of verified, freely-licensed Unsplash photos (Unsplash
License — free for commercial use) are reused across the site with
different color-tint overlays per section (see `.img-tint--*` classes in
`assets/css/style.css`), so the repetition reads as an intentional,
cohesive visual palette rather than accidental duplication. Swap any
`IMG_*` constant at the top of `includes/data.php` for real academy
photography whenever it's available — every page will update
automatically.

## What's included

- 11 pages: Home, About, Courses, Course Detail, Instructors, Instructor
  Detail, Gallery, Events, Services, Testimonials, Contact
- 32 courses across Dance (12), Singing (9), and Choreography (11 — split
  between "Learn Choreography" courses and "Hire Choreography" event services)
- Category + subcategory filtering and live search on the Courses page (JS only)
- Horizontal drag-to-scroll course row on the homepage (mouse + touch)
- FAQ accordions, gallery lightbox, mobile hamburger nav, scroll-reveal
  animations — all vanilla JavaScript, all respecting `prefers-reduced-motion`
- A static, JS-validated contact form that stores nothing anywhere

## What was verified before delivery

- Every `.php` file passed `php -l` syntax checking
- Every page was loaded over a live local server with zero PHP warnings,
  notices, or errors
- Every course-detail and instructor-detail link generated by the listing
  pages was checked and confirmed to resolve (no broken links)
- The entire codebase was scanned for forbidden terms (`mysql`, `PDO`,
  `login`, `admin`, `dashboard`, `session_start`, etc.) — none found outside
  a single comment explicitly confirming their absence

## File structure

```
├── index.php, about.php, courses.php, course-detail.php
├── instructors.php, instructor-detail.php
├── gallery.php, events.php, services.php, testimonials.php, contact.php
├── includes/
│   ├── header.php        — nav (now includes an Admin link), <head>
│   ├── footer.php        — footer, script include
│   ├── data.php          — static content + admin-override merging logic
│   ├── config.php        — DB connection, CSRF, session, admin auth helpers
│   ├── admin-header.php  — NEW: shared layout/nav for every admin/ page
│   └── admin-footer.php  — NEW
├── admin/
│   ├── login.php           — username + password (from admin_users table)
│   ├── logout.php
│   ├── index.php           — NEW: dashboard with stats + quick links
│   ├── messages.php        — view/manage contact submissions
│   ├── courses.php         — NEW: edit course prices
│   ├── media.php           — NEW: upload replacement photos
│   └── change-password.php — NEW: change your own admin password
├── database/
│   ├── schema.sql          — contact_messages
│   └── admin-features.sql  — NEW: admin_users, course_overrides, site_images
└── assets/
    ├── css/style.css
    ├── js/main.js
    └── images/
        ├── logo.png
        ├── gallery/   — 11 real bundled photos (Pexels-licensed)
        └── uploads/   — NEW: admin-uploaded replacement photos land here
```
