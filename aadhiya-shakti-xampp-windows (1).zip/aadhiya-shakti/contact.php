<?php
require_once __DIR__ . '/includes/config.php';

$errors  = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors['form'] = 'Your session expired. Please try submitting again.';
    } else {
        $name    = trim((string) ($_POST['name'] ?? ''));
        $email   = trim((string) ($_POST['email'] ?? ''));
        $phone   = trim((string) ($_POST['phone'] ?? ''));
        $service = trim((string) ($_POST['service'] ?? ''));
        $message = trim((string) ($_POST['message'] ?? ''));

        if ($name === '') $errors['name'] = 'Please enter your name.';
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Please enter a valid email address.';
        if ($service === '') $errors['service'] = 'Please select a service.';
        if ($message === '') $errors['message'] = 'Please enter a message.';

        if (empty($errors)) {
            $stmt = db()->prepare(
                'INSERT INTO contact_messages (name, email, phone, service, message)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([$name, $email, $phone ?: null, $service, $message]);
            $success = true;

            // Clear submitted values after a successful save so the form
            // doesn't re-populate with old data on refresh.
            $_POST = [];
        }
    }
}

$page_title = 'Contact — Aadhiya Shakti Academy';
$page_description = 'Get in touch with Aadhiya Shakti Academy about courses or choreography services.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$faqs = get_faqs();
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">Get In Touch</span>
    <h1>Contact Us</h1>
    <p>Questions about a course, or want to discuss choreography for an event? Reach out below.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container contact-grid">

    <div>
      <h2>Contact Details</h2>
      <p style="color:var(--charcoal-soft); margin-top:10px;">Contact information below is a placeholder pending confirmation — this is a demo project.</p>
      <div class="contact-info-list">
        <div class="contact-info-item"><strong>Email</strong>[EMAIL TO BE CONFIRMED]</div>
        <div class="contact-info-item"><strong>Phone</strong>[PHONE NUMBER TO BE CONFIRMED]</div>
        <div class="contact-info-item"><strong>Address</strong>[ADDRESS TO BE CONFIRMED]</div>
        <div class="contact-info-item">
          <strong>Social</strong>
          <a href="[OFFICIAL INSTAGRAM URL]" style="color:var(--terracotta); font-weight:600;">Instagram</a> ·
          <a href="[OFFICIAL X URL]" style="color:var(--terracotta); font-weight:600;">X / Twitter</a>
        </div>
      </div>

      <div style="background: linear-gradient(160deg, var(--terracotta), var(--coral)); border-radius: var(--radius-lg); padding: 26px 28px; margin-top: 28px; box-shadow: var(--shadow-soft);">
        <h3 style="color: var(--ivory); margin-bottom: 4px;">Service Areas</h3>
        <p style="color: rgba(255,235,184,0.8); font-size: 0.85rem; margin-bottom: 18px;">
          Planned / supported locations — not confirmed physical branches unless stated otherwise.
        </p>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 12px 20px;">
          <?php foreach (['Jamnagar', 'Ahmedabad', 'Vadodara', 'Surat', 'Rajkot', 'Online (All India)'] as $loc): ?>
            <div style="display:flex; align-items:center; gap:8px; color: var(--ivory); font-weight:600; font-size:0.92rem;">
              <span style="width:8px; height:8px; border-radius:50%; background: var(--ivory); flex-shrink:0;"></span>
              <?= e($loc) ?>
            </div>
          <?php endforeach; ?>
        </div>
        <p style="color: rgba(255,235,184,0.65); font-size: 0.78rem; margin-top: 18px;">Gujarat, India — plus online classes available across the country.</p>
      </div>
    </div>

    <div class="form-card">
      <?php if ($success): ?>
        <div class="form-success" style="display:block;">
          Thank you — your message has been received. The academy will get back to you soon.
        </div>
      <?php elseif (!empty($errors['form'])): ?>
        <div class="form-success" style="display:block; background:var(--peach); color:var(--terracotta);"><?= e($errors['form']) ?></div>
      <?php endif; ?>

      <form data-contact-form method="post" action="contact.php" novalidate>
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <div class="form-row">
          <label for="name">Name</label>
          <input type="text" id="name" name="name" required value="<?= e($_POST['name'] ?? '') ?>">
          <span class="error-text" <?= !empty($errors['name']) ? 'style="display:block;"' : '' ?>><?= e($errors['name'] ?? '') ?></span>
        </div>
        <div class="form-row">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">
          <span class="error-text" <?= !empty($errors['email']) ? 'style="display:block;"' : '' ?>><?= e($errors['email'] ?? '') ?></span>
        </div>
        <div class="form-row">
          <label for="phone">Phone</label>
          <input type="tel" id="phone" name="phone" value="<?= e($_POST['phone'] ?? '') ?>">
        </div>
        <div class="form-row">
          <label for="service">Service</label>
          <select id="service" name="service" required>
            <option value="">Select a service</option>
            <?php foreach (['dance' => 'Dance Courses', 'singing' => 'Singing Courses', 'choreography-learn' => 'Learn Choreography', 'choreography-hire' => 'Hire Choreography for an Event', 'other' => 'Something Else'] as $val => $label): ?>
              <option value="<?= e($val) ?>" <?= (($_POST['service'] ?? '') === $val) ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="error-text" <?= !empty($errors['service']) ? 'style="display:block;"' : '' ?>><?= e($errors['service'] ?? '') ?></span>
        </div>
        <div class="form-row">
          <label for="message">Message</label>
          <textarea id="message" name="message" rows="4" required><?= e($_POST['message'] ?? '') ?></textarea>
          <span class="error-text" <?= !empty($errors['message']) ? 'style="display:block;"' : '' ?>><?= e($errors['message'] ?? '') ?></span>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">Send Message</button>
        <p style="font-size:0.78rem; color:var(--charcoal-soft); margin-top:12px; text-align:center;">
          Your message is stored securely and only visible to the academy's admin team.
        </p>
      </form>
    </div>

  </div>
</section>

<section style="background:var(--paper);">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Common Questions</span>
      <h2>FAQ</h2>
    </div>
    <div class="faq-list">
      <?php foreach ($faqs as $f): ?>
        <div class="faq-item">
          <button class="faq-question"><?= e($f['q']) ?><span class="plus">+</span></button>
          <div class="faq-answer"><p><?= e($f['a']) ?></p></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
