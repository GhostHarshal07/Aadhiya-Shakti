<?php
require_once __DIR__ . '/../includes/config.php';
admin_require_login();
admin_require_permission('manage_admins');

$q = trim((string) ($_GET['q'] ?? ''));
$user = trim((string) ($_GET['user'] ?? ''));
$sql = 'SELECT * FROM admin_activity_log WHERE 1=1';
$args = [];
if ($q !== '')    { $sql .= ' AND (action LIKE ? OR description LIKE ?)'; array_push($args, "%$q%", "%$q%"); }
if ($user !== '') { $sql .= ' AND admin_username = ?'; $args[] = $user; }
$stmt = db()->prepare($sql . ' ORDER BY id DESC LIMIT 200');
$stmt->execute($args);
$rows = $stmt->fetchAll();
$users = db()->query('SELECT DISTINCT admin_username FROM admin_activity_log ORDER BY 1')->fetchAll(PDO::FETCH_COLUMN);

$admin_page_title = 'Activity Log';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<h1>Activity Log</h1>
<p style="color:var(--charcoal-soft);">The 200 most recent admin actions.</p>
<form class="filters" method="get">
  <input type="search" name="q" placeholder="Search action or description…" value="<?= e($q) ?>">
  <select name="user"><option value="">All admins</option><?php foreach ($users as $u): ?><option <?= $user === $u ? 'selected' : '' ?>><?= e($u) ?></option><?php endforeach; ?></select>
  <button class="btn btn-outline btn-sm" type="submit">Filter</button>
</form>
<div class="tbl-wrap"><table class="tbl">
  <thead><tr><th>When</th><th>Admin</th><th>Action</th><th>Details</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr><td style="white-space:nowrap;font-size:.8rem;"><?= e($r['created_at']) ?></td><td><?= e($r['admin_username']) ?></td><td><span class="badge"><?= e($r['action']) ?></span></td><td><?= e($r['description']) ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="4" style="text-align:center;color:var(--charcoal-soft);padding:30px;">No activity yet.</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
