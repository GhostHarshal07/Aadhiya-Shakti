<?php
require_once __DIR__ . '/../includes/config.php';
admin_require_login();
admin_require_permission('manage_categories');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        toast_set('Your session expired. Please try again.', 'error');
    } else {
        $pdo = db();
        $a = $_POST['action'] ?? '';
        $name = trim((string) ($_POST['name'] ?? ''));
        $id = (int) ($_POST['id'] ?? 0);
        if ($a === 'add_cat' && $name !== '') {
            $slug = slugify($name);
            $pdo->prepare('INSERT IGNORE INTO categories (slug, name, blurb) VALUES (?,?,?)')->execute([$slug, $name, trim((string) ($_POST['blurb'] ?? ''))]);
            admin_log('category_create', "Added category \"$name\"");
            toast_set('Category added.');
        } elseif ($a === 'add_sub' && $name !== '' && $id) {
            $pdo->prepare('INSERT IGNORE INTO subcategories (category_id, slug, name) VALUES (?,?,?)')->execute([$id, slugify($name), $name]);
            admin_log('subcategory_create', "Added subcategory \"$name\"");
            toast_set('Subcategory added.');
        } elseif ($a === 'del_cat' && $id) {
            $n = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE category_id = ?');
            $n->execute([$id]);
            if ($n->fetchColumn() > 0) {
                toast_set('That category still has courses. Move or delete them first.', 'error');
            } else {
                $pdo->prepare('DELETE FROM categories WHERE id = ?')->execute([$id]);
                admin_log('category_delete', "Deleted category #$id");
                toast_set('Category deleted.');
            }
        } elseif ($a === 'del_sub' && $id) {
            $pdo->prepare('DELETE FROM subcategories WHERE id = ?')->execute([$id]);
            admin_log('subcategory_delete', "Deleted subcategory #$id");
            toast_set('Subcategory deleted.');
        }
    }
    redirect('categories.php');
}

$cats = db()->query('SELECT c.*, (SELECT COUNT(*) FROM courses WHERE category_id = c.id) AS n FROM categories c ORDER BY c.name')->fetchAll();
$subs = [];
foreach (db()->query('SELECT * FROM subcategories ORDER BY name')->fetchAll() as $s) { $subs[$s['category_id']][] = $s; }

$admin_page_title = 'Categories';
require_once __DIR__ . '/../includes/admin-header.php';
$tok = e(csrf_token());
?>
<h1>Categories</h1>
<?php if (!$cats): ?><div class="admin-alert admin-alert-error" style="margin-top:14px;">No categories yet — run <a href="../database/migrate.php" style="text-decoration:underline;">database/migrate.php</a> once to import the built-in ones.</div><?php endif; ?>

<form method="post" class="admin-card" style="margin-top:18px; display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end;">
  <input type="hidden" name="csrf_token" value="<?= $tok ?>"><input type="hidden" name="action" value="add_cat">
  <div class="form-row" style="margin:0;flex:1;min-width:180px;"><label>New category</label><input name="name" required></div>
  <div class="form-row" style="margin:0;flex:2;min-width:220px;"><label>Short blurb</label><input name="blurb"></div>
  <button class="btn btn-primary btn-sm" type="submit">Add category</button>
</form>

<?php foreach ($cats as $c): ?>
  <div class="admin-card">
    <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;">
      <h3><?= e($c['name']) ?> <span class="badge"><?= (int) $c['n'] ?> courses</span></h3>
      <form method="post" data-confirm="Delete category “<?= e($c['name']) ?>” and its subcategories?">
        <input type="hidden" name="csrf_token" value="<?= $tok ?>"><input type="hidden" name="action" value="del_cat"><input type="hidden" name="id" value="<?= $c['id'] ?>">
        <button class="btn-link danger" type="submit">Delete category</button>
      </form>
    </div>
    <div style="margin:12px 0;display:flex;flex-wrap:wrap;gap:8px;">
      <?php foreach ($subs[$c['id']] ?? [] as $s): ?>
        <form method="post" data-confirm="Delete subcategory “<?= e($s['name']) ?>”? Courses in it will become uncategorised within <?= e($c['name']) ?>." style="display:inline-flex;align-items:center;gap:4px;background:var(--ivory);padding:4px 6px 4px 12px;border-radius:100px;font-size:.82rem;font-weight:600;">
          <?= e($s['name']) ?>
          <input type="hidden" name="csrf_token" value="<?= $tok ?>"><input type="hidden" name="action" value="del_sub"><input type="hidden" name="id" value="<?= $s['id'] ?>">
          <button class="btn-link danger" type="submit" aria-label="Delete">✕</button>
        </form>
      <?php endforeach; ?>
    </div>
    <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;">
      <input type="hidden" name="csrf_token" value="<?= $tok ?>"><input type="hidden" name="action" value="add_sub"><input type="hidden" name="id" value="<?= $c['id'] ?>">
      <input name="name" placeholder="New subcategory" required style="padding:9px 14px;border:1.5px solid var(--border);border-radius:10px;font-family:inherit;">
      <button class="btn btn-outline btn-sm" type="submit">Add subcategory</button>
    </form>
  </div>
<?php endforeach; ?>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
