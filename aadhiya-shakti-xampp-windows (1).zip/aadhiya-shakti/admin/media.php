<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';
admin_require_login();
admin_require_permission('manage_photos');

// The specific, named "slots" an admin can replace a photo for. Adding a
// new slot here (plus a get_site_image() call on the relevant public page)
// is the only step needed to make another spot on the site editable.
$slots = [
    'category_dance'        => ['label' => 'Dance category card',        'default' => IMG_KATHAKALI],
    'category_singing'      => ['label' => 'Singing category card',      'default' => IMG_STUDIO_BAND],
    'category_choreography' => ['label' => 'Choreography category card', 'default' => IMG_MARCHING_BAND],
    'about_main'            => ['label' => 'About page main photo',      'default' => IMG_BHARATANATYAM],
];

$success = null;
$error   = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        $key = (string) ($_POST['image_key'] ?? '');

        if (!isset($slots[$key])) {
            $error = 'Unknown photo slot.';
        } elseif (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
            $error = 'Please choose an image file to upload.';
        } else {
            $file = $_FILES['photo'];

            // 1. Size limit (5 MB)
            if ($file['size'] > 5 * 1024 * 1024) {
                $error = 'That image is too large — please choose a file under 5 MB.';
            } else {
                // 2. Verify it's ACTUALLY an image by reading its real content
                //    (not just trusting the filename/extension, which anyone
                //    can fake). getimagesize() fails on non-image files.
                $imageInfo = @getimagesize($file['tmp_name']);
                $allowedTypes = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];

                if ($imageInfo === false || !isset($allowedTypes[$imageInfo[2]])) {
                    $error = 'That file doesn\'t look like a valid image (JPG, PNG, WEBP, or GIF only).';
                } else {
                    // 3. Generate a new, safe filename ourselves — never trust
                    //    the uploader's original filename, which could contain
                    //    path traversal characters or a disguised extension.
                    $extension = $allowedTypes[$imageInfo[2]];
                    $safeFilename = $key . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
                    $destination = __DIR__ . '/../assets/images/uploads/' . $safeFilename;

                    if (move_uploaded_file($file['tmp_name'], $destination)) {
                        $stmt = db()->prepare(
                            'INSERT INTO site_images (image_key, filename)
                             VALUES (?, ?)
                             ON DUPLICATE KEY UPDATE filename = VALUES(filename), updated_at = NOW()'
                        );
                        $stmt->execute([$key, $safeFilename]);
                        $success = 'Photo updated for "' . $slots[$key]['label'] . '".'; admin_log('photo_update', $success);
                    } else {
                        $error = 'The upload failed. Please try again.';
                    }
                }
            }
        }
    }
}

$admin_page_title = 'Site Photos';
require_once __DIR__ . '/../includes/admin-header.php';
?>

<?php if ($success): ?><div class="admin-alert admin-alert-success"><?= e($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="admin-alert admin-alert-error"><?= e($error) ?></div><?php endif; ?>

<p style="color:var(--charcoal-soft); margin-bottom:20px;">
  Replace any of these photos with your own, straight from your computer. JPG, PNG, WEBP, or GIF — up to 5&nbsp;MB. The rest of the page around each photo stays exactly the same.
</p>

<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap:20px;">
  <?php foreach ($slots as $key => $slot): ?>
    <?php $currentImage = get_site_image($key, $slot['default']); ?>
    <div class="admin-card">
      <div class="img-tint" style="aspect-ratio:4/3; margin-bottom:14px;">
        <img src="<?= e('../' . $currentImage) ?>" alt="<?= e($slot['label']) ?>" style="width:100%; height:100%; object-fit:cover; border-radius:var(--radius-md);">
      </div>
      <strong style="display:block; margin-bottom:12px;"><?= e($slot['label']) ?></strong>
      <form method="post" action="media.php" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="image_key" value="<?= e($key) ?>">
        <div class="form-row">
          <input type="file" name="photo" accept="image/jpeg,image/png,image/webp,image/gif" required>
        </div>
        <button type="submit" class="btn btn-primary btn-sm" style="width:100%; justify-content:center;">Upload &amp; Replace</button>
      </form>
    </div>
  <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
