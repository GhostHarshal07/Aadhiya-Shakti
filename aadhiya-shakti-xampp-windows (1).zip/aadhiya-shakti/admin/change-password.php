<?php
require_once __DIR__ . '/../includes/config.php';
admin_require_login();

$success = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        $current = (string) ($_POST['current_password'] ?? '');
        $new     = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        $admin = admin_current();
        $stmt = db()->prepare('SELECT password_hash FROM admin_users WHERE id = ?');
        $stmt->execute([$admin['id']]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($current, $row['password_hash'])) {
            $error = 'Your current password is incorrect.';
        } elseif (strlen($new) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif ($new !== $confirm) {
            $error = 'New password and confirmation do not match.';
        } else {
            $newHash = password_hash($new, PASSWORD_DEFAULT);
            db()->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?')->execute([$newHash, $admin['id']]);
            $success = 'Password updated successfully.';
        }
    }
}

$admin_page_title = 'Change Password';
require_once __DIR__ . '/../includes/admin-header.php';
?>

<?php if ($success): ?><div class="admin-alert admin-alert-success"><?= e($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="admin-alert admin-alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="form-card" style="max-width:440px;">
  <form method="post" action="change-password.php">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="form-row">
      <label for="current_password">Current Password</label>
      <input type="password" id="current_password" name="current_password" required>
    </div>
    <div class="form-row">
      <label for="new_password">New Password</label>
      <input type="password" id="new_password" name="new_password" required minlength="8">
    </div>
    <div class="form-row">
      <label for="confirm_password">Confirm New Password</label>
      <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
    </div>
    <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">Update Password</button>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
