<?php
$page_title = 'Testimonials — Aadhiya Shakti Academy';
$page_description = 'Sample testimonials about dance, singing, and choreography services at Aadhiya Shakti Academy.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$testimonials = get_testimonials();
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">Sample Testimonials</span>
    <h1>What Learners &amp; Clients Say</h1>
    <p>These are sample/demo testimonials written for this project. They are not verified reviews from real customers.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="testimonial-grid">
      <?php foreach ($testimonials as $t): ?>
        <div class="testimonial-card reveal">
          <div class="stars">★★★★★</div>
          <p class="quote">&ldquo;<?= htmlspecialchars($t['quote']) ?>&rdquo;</p>
          <div class="testimonial-person"><?= htmlspecialchars($t['name']) ?><span><?= htmlspecialchars($t['service']) ?></span></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
