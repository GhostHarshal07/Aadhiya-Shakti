-- Aadhiya Shakti Academy — COMPLETE database in one file (tables + 3 categories, 32 courses, 10 tutors, 1 admin).
-- Import into phpMyAdmin: create DB 'aadhiya_shakti_site' (utf8mb4_general_ci) -> select it -> Import this file.
CREATE DATABASE IF NOT EXISTS aadhiya_shakti_site CHARACTER SET utf8mb4;
USE aadhiya_shakti_site;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admin_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_activity_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `admin_username` varchar(60) NOT NULL,
  `action` varchar(60) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_log_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `admin_activity_log` DISABLE KEYS */;
INSERT INTO `admin_activity_log` VALUES
(1,NULL,'system','migrate','Ran database/migrate.php','2026-10-04 08:46:37');
/*!40000 ALTER TABLE `admin_activity_log` ENABLE KEYS */;
DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `full_name` varchar(120) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'super_admin',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `permissions` text DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES
(1,'admin','$2y$10$DPWWH7JwvLMiezCqcsSTbuPSF2eYiTL7ftUH44.v3vRhz.BiDDgQC','2026-10-04 08:46:37',NULL,NULL,'super_admin','active',NULL,NULL);
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(80) NOT NULL,
  `name` varchar(120) NOT NULL,
  `blurb` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_key` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'dance','Dance','From classical Bharatanatyam and Kathak to Bollywood and contemporary movement — structured training for every age and level.','assets/images/gallery/kathakali-group.jpg','category_dance'),
(2,'singing','Singing','Classical, folk, devotional and contemporary vocal training built on breath control, pitch accuracy, and stage confidence.','assets/images/gallery/studio-band.jpg','category_singing'),
(3,'choreography','Choreography','Two paths: learn choreography as a structured course, or hire the academy\'s team to choreograph and stage your event.','assets/images/gallery/marching-band.jpg','category_choreography');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `service` varchar(60) NOT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','archived') NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_contact_messages_status` (`status`),
  KEY `idx_contact_messages_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
DROP TABLE IF EXISTS `course_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_overrides` (
  `course_slug` varchar(180) NOT NULL,
  `price` varchar(60) NOT NULL,
  `price_note` varchar(30) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`course_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `course_overrides` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_overrides` ENABLE KEYS */;
DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `subcategory_id` int(10) unsigned DEFAULT NULL,
  `instructor_slug` varchar(120) DEFAULT NULL,
  `title` varchar(190) NOT NULL,
  `slug` varchar(190) NOT NULL,
  `level` varchar(60) NOT NULL DEFAULT 'Beginner',
  `duration` varchar(80) NOT NULL DEFAULT '',
  `mode` varchar(60) NOT NULL DEFAULT 'Online',
  `price` varchar(80) NOT NULL DEFAULT '',
  `price_note` varchar(40) NOT NULL DEFAULT 'Sample Pricing',
  `image` varchar(255) DEFAULT NULL,
  `excerpt` varchar(400) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `outcomes` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`),
  KEY `subcategory_id` (`subcategory_id`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES
(1,1,1,'dr-kavya-nair','Classical Dance Foundation','classical-dance-foundation','Beginner','12 Weeks','Online + In-Studio','₹2,499/month','Sample Pricing','assets/images/gallery/bharatanatyam-dramatic.jpg','Foundational Bharatanatyam adavus, posture, and rhythm for complete beginners.','A structured entry point into Bharatanatyam, this course builds the postural discipline, footwork, and rhythmic sense that everything else in classical dance is built on. No prior experience needed.','Correct posture (aramandi) and basic adavus\nHand gestures (hastas) and their meanings\nRhythm counting with nattuvangam\nYour first short performance piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(2,1,1,'meera-iyer','Kathak Foundations','kathak-foundations','Beginner','12 Weeks','In-Studio','₹2,499/month','Sample Pricing','https://images.unsplash.com/photo-1479813183133-f2e9b38ed6c4?auto=format&fit=crop&w=1400&q=80','Footwork, spins (chakkars), and storytelling gesture from the Kathak tradition.','Kathak\'s intricate footwork and spins take time to build safely — this course paces that development while introducing the storytelling (abhinaya) side of the form from early on.','Basic tatkar (footwork) patterns\nControlled single and double chakkars\nIntroductory hand gestures and expression\nA short thumri-based performance piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(3,1,2,'ananya-rao','Folk Dance Essentials','folk-dance-essentials','Beginner','8 Weeks','In-Studio','₹1,999/month','Sample Pricing','assets/images/gallery/kathakali-group.jpg','Regional folk forms taught with attention to their cultural context, not just steps.','A rotating survey of regional folk dance styles, taught with the cultural and rhythmic context behind each form rather than steps in isolation.','Core folk footwork across 2–3 regional styles\nGroup formation and spacing\nRhythmic clapping and prop work (dandiya sticks, etc.)\nA group folk performance piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(4,1,3,'ananya-rao','Garba & Regional Dance','garba-regional-dance','All Levels','6 Weeks (seasonal)','In-Studio','₹1,799/month','Sample Pricing','assets/images/gallery/manipuri-dancer-1.jpg','Garba and dandiya technique ahead of Navratri, for total beginners and returners alike.','A seasonal course timed around Navratri, covering traditional garba circles and dandiya (stick) work at a pace that welcomes complete beginners.','Basic garba circle footwork\nDandiya raas partner technique\nBuilding stamina for extended play\nConfidence dancing in a group setting','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(5,1,4,'royan-mehta','Bollywood Dance Basics','bollywood-dance-basics','Beginner','8 Weeks','Online + In-Studio','₹1,999/month','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','Fun, high-energy Bollywood choreography drawn from current and classic film numbers.','A fitness-friendly, high-energy course with no prior dance experience required — built around full choreography routines to popular film songs.','Bollywood dance vocabulary and isolations\nTwo to three full choreography routines per term\nExpression and camera-ready performance energy\nBasic freestyle confidence','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(6,1,5,'royan-mehta','Contemporary Movement','contemporary-movement','Intermediate','10 Weeks','In-Studio','₹2,999/month','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','Contemporary technique building on floorwork, control, and improvisation.','For students with some dance background who want to develop a more contemporary movement vocabulary — floorwork, weight-sharing, and structured improvisation.','Floorwork and controlled falls\nImprovisation frameworks\nPartnering and weight-sharing basics\nAn original short movement piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(7,1,6,'royan-mehta','Wedding Dance Training','wedding-dance-training','All Levels','4 Weeks','In-Studio','₹3,499 (couple package)','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','A short, focused course for couples or wedding parties preparing a sangeet performance.','Designed for couples, bridal parties, or families preparing a performance for their own wedding sangeet — a compact, deadline-driven course rather than an ongoing program.','A complete choreographed routine to your chosen song\nBasic partner lifts/holds (where appropriate)\nConfidence performing in front of a crowd\nA run-through rehearsal close to the event date','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(8,1,7,'ananya-rao','Group Dance Performance','group-dance-performance','Intermediate','10 Weeks','In-Studio','₹2,499/month','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','Ensemble choreography focused on synchronisation, formations, and stage spacing.','Built for students who already have foundational technique and want to work specifically on the group skills — synchronisation, formation changes, spacing — that solo classes don\'t cover.','Synchronised group timing\nFormation transitions\nStage spacing and blocking awareness\nA full ensemble performance piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(9,1,8,'meera-iyer','School Dance Program','school-dance-program','Beginner (Ages 8–14)','12 Weeks','In-Studio','₹1,499/month','Sample Pricing','https://images.unsplash.com/photo-1479813183133-f2e9b38ed6c4?auto=format&fit=crop&w=1400&q=80','An age-appropriate structured program for school-age children new to dance.','A gentler-paced program specifically structured for school-age beginners, balancing technique fundamentals with confidence-building and fun.','Basic posture and coordination\nSimple choreography sequences\nComfort performing in front of others\nA term-end recital piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(10,1,9,'dr-kavya-nair','Kids Dance Fundamentals','kids-dance-fundamentals','Kids (Ages 5–10)','12 Weeks','In-Studio','₹1,499/month','Sample Pricing','https://images.unsplash.com/photo-1479813183133-f2e9b38ed6c4?auto=format&fit=crop&w=1400&q=80','A playful introduction to movement, rhythm, and body awareness for young children.','Focused on movement literacy rather than technique drilling — young children build rhythm, coordination, and comfort with performing through games and simple sequences.','Basic rhythm and movement games\nSimple sequences and spatial awareness\nFollowing group instructions\nA short, low-pressure showcase','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(11,1,10,'royan-mehta','Competition Dance Training','competition-dance-training','Advanced','16 Weeks','In-Studio','₹3,999/month','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','Intensive preparation for students competing in dance competitions or eisteddfods.','A demanding, performance-focused track for advanced students actively preparing for competitions — heavier rehearsal load and individualised choreography feedback.','Competition-ready choreography\nPerformance polish and consistency under pressure\nCostume and staging considerations\nMock-competition run-throughs','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(12,1,11,'meera-iyer','Stage Performance Training','stage-performance-training-dance','Advanced','8 Weeks','In-Studio','₹2,999/month','Sample Pricing','assets/images/gallery/manipuri-dancer-2.jpg','Refining performance quality, expression, and stage presence for advanced dancers.','For technically strong dancers who want to sharpen what happens beyond the steps — projection, expression, and command of a stage.','Stage presence and projection\nWorking with lighting and spacing cues\nExpression (abhinaya/emotive) refinement\nA polished solo performance piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(13,2,12,'nikhil-bansal','Classical Vocal Foundation','classical-vocal-foundation','Beginner','12 Weeks','Online + In-Studio','₹2,299/month','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','Swara, shruti, and taal fundamentals for students new to classical vocal training.','Starts from breath control and swara (note) practice and builds toward singing a first short bandish — the essential groundwork most classical vocal training assumes you already have.','Breath control and voice culture\nSwara and shruti awareness\nBasic taal (rhythm cycle) counting\nA short first bandish','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(14,2,13,'priyanka-sethi','Folk Singing Essentials','folk-singing-essentials','Beginner','8 Weeks','In-Studio','₹1,899/month','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','Regional folk singing styles and their characteristic ornamentation and rhythm.','Covers a rotating selection of regional folk singing traditions, with attention to the ornamentation and call-and-response patterns that distinguish folk styles from classical ones.','Folk ornamentation techniques\nCall-and-response singing\nRegional rhythm patterns\nA group folk song performance','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(15,2,14,'arnav-chatterjee','Bollywood Vocal Training','bollywood-vocal-training','Beginner–Intermediate','10 Weeks','Online + In-Studio','₹2,199/month','Sample Pricing','assets/images/gallery/guitar-closeup.jpg','Pitch accuracy, breath support, and phrasing for popular film-song singing.','Built for students who want to sing contemporary Bollywood songs confidently, with real attention to pitch accuracy and breath support rather than just mimicking a recording.','Pitch accuracy and ear training\nBreath support for sustained phrases\nMicrophone technique basics\nA performance-ready song repertoire','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(16,2,15,'akash-gupta','Group Singing Workshop','group-singing-workshop','All Levels','6 Weeks','In-Studio','₹1,699/month','Sample Pricing','assets/images/gallery/band-performance.jpg','Harmony, blending, and choral discipline for singing as an ensemble.','A workshop-style course focused specifically on the skills solo lessons don\'t cover: blending your voice with others, harmony parts, and choral discipline.','Basic harmony singing\nVocal blending within a group\nChoral discipline and cueing\nA group performance piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(17,2,16,'priyanka-sethi','Patriotic Singing Program','patriotic-singing-program','All Levels','4 Weeks (seasonal)','In-Studio','₹1,499 (flat)','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','A short seasonal program preparing patriotic songs for school and community events.','Timed around national observances, this short program prepares students to perform patriotic songs at school assemblies or community events.','Clear diction and projection\nGroup timing for ensemble singing\nStage discipline for formal events\nA rehearsed set for a specific occasion','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(18,2,17,'nikhil-bansal','Devotional Singing','devotional-singing','All Levels','8 Weeks','In-Studio','₹1,899/month','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','Bhajans and devotional repertoire, with attention to mood and simple melodic structure.','Focused on devotional repertoire (bhajans and related forms), where the goal is emotional sincerity and melodic clarity rather than technical complexity.','Common devotional ragas and structures\nSimple harmonium accompaniment basics\nGroup call-and-response bhajan singing\nA devotional set for a gathering or event','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(19,2,18,'vidya-krishnan','Kids Vocal Basics','kids-vocal-basics','Kids (Ages 6–12)','12 Weeks','In-Studio','₹1,499/month','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','A gentle, playful introduction to pitch, breath, and confident singing for children.','Introduces young children to singing through games and simple songs, prioritising comfort and enjoyment while gently building pitch awareness.','Basic pitch matching\nSimple breath control exercises\nComfort singing solo and in a group\nA short, low-pressure showcase','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(20,2,19,'devansh-oberoi','Stage Singing Preparation','stage-singing-preparation','Intermediate–Advanced','8 Weeks','In-Studio','₹2,499/month','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','Microphone technique, stage presence, and performance polish for public singing.','For students who already sing well and want to close the gap between \"singing in a lesson\" and \"performing on a stage\" — mic technique, nerves, and presence.','Microphone technique and positioning\nManaging performance nerves\nStage presence and audience connection\nA polished performance set','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(21,2,19,'akash-gupta','Vocal Training','vocal-training-general','All Levels','Ongoing','Online + In-Studio','₹1,999/month','Sample Pricing','https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80','General ongoing vocal training and riyaz (practice) discipline, style-flexible.','An open-ended, ongoing vocal program for students who want continued riyaz (practice) discipline without committing to one specific style track.','Consistent riyaz (practice) habits\nVoice health and warm-up routines\nStyle-flexible repertoire building\nRegular progress check-ins','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(22,3,20,'royan-mehta','Choreography Foundations','choreography-foundations','Beginner','8 Weeks','In-Studio','₹2,199/month','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','Learn to build and structure choreography, not just perform it.','For dancers who want to move from performing choreography to creating it — structuring a routine, counting music, and directing a group.','Reading and counting music for choreography\nStructuring a routine (formations, transitions)\nBasic group directing skills\nAn original short choreographed piece','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(23,3,20,'royan-mehta','Stage Performance Choreography','stage-performance-choreography-learn','Intermediate','8 Weeks','In-Studio','₹2,499/month','Sample Pricing','https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80','Advanced choreography techniques for staged, ensemble performance work.','Builds on choreography fundamentals with a focus on staging for a real audience — blocking, spacing, and directing a full ensemble piece.','Advanced formation and blocking work\nDirecting a full ensemble piece\nWorking with music edits and cues\nA staged group performance','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(24,3,21,NULL,'Wedding Choreography','wedding-choreography','N/A (Service)','Custom (per event)','On-Location','₹9,999','Starting From','assets/images/gallery/kathakali-group.jpg','Choreography and rehearsal support for sangeet and wedding performances.','The academy\'s choreography team works with the wedding party to design, teach, and rehearse a performance — timeline and scope discussed directly with you.','A custom-choreographed routine\nStructured rehearsal sessions ahead of the event\nOn-the-day coordination support (by arrangement)\nMusic editing assistance (by arrangement)','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(25,3,22,NULL,'School Function Choreography','school-function-choreography','N/A (Service)','Custom (per event)','On-Location','₹6,999','Starting From','assets/images/gallery/marching-band.jpg','Choreography support for school annual days, functions, and assemblies.','Group choreography designed and taught for school events, scaled to the age group and number of students involved.','Age-appropriate group choreography\nOn-site or in-school rehearsal sessions\nCostume and formation guidance\nSupport on the day of the event (by arrangement)','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(26,3,23,NULL,'College Function Choreography','college-function-choreography','N/A (Service)','Custom (per event)','On-Location','₹7,999','Starting From','assets/images/gallery/marching-band.jpg','Choreography for college fests, competitions, and cultural events.','Choreography designed for the higher energy and competitive context of college cultural events and fests.','Competition-oriented choreography\nGroup rehearsal scheduling\nMusic selection and editing guidance\nFormation work for larger groups','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(27,3,26,NULL,'Corporate Event Choreography','corporate-event-choreography','N/A (Service)','Custom (per event)','On-Location','₹12,999','Starting From','https://images.unsplash.com/photo-1624234636182-6d61fe4cd140?auto=format&fit=crop&w=1400&q=80','Choreography for corporate offsites, annual days, and team performances.','Designed for employees with limited rehearsal time — accessible choreography built for a corporate performance, not a dance background.','Beginner-friendly group choreography\nCompressed rehearsal schedules for working professionals\nFormation guidance for larger corporate groups\nOn-the-day support (by arrangement)','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(28,3,24,NULL,'Party Choreography','party-choreography','N/A (Service)','Custom (per event)','On-Location','₹4,999','Starting From','assets/images/gallery/birthday-party.jpg','Light, fun choreography for birthdays, engagements, and private parties.','A shorter-scope service for one-off private parties — a fun, low-pressure routine rather than a formal show.','A short, fun group routine\n1–2 rehearsal sessions\nMusic selection guidance\nOn-the-day walkthrough','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(29,3,27,NULL,'Cultural Event Choreography','cultural-event-choreography','N/A (Service)','Custom (per event)','On-Location','₹8,999','Starting From','assets/images/gallery/kathakali-group.jpg','Choreography for community cultural programs and festival celebrations.','Choreography rooted in traditional and folk vocabulary, designed for community cultural programs and festival celebrations.','Culturally-grounded group choreography\nRehearsal scheduling around community availability\nCostume and prop guidance\nOn-the-day coordination (by arrangement)','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(30,3,28,NULL,'Annual Function Choreography','annual-function-choreography','N/A (Service)','Custom (per event)','On-Location','₹7,499','Starting From','assets/images/gallery/marching-band.jpg','End-to-end choreography for institutional annual day celebrations.','Built for the scale and formality of an annual day — typically multiple groups or age bands performing across one program.','Choreography across multiple performance slots\nCoordinated rehearsal calendar\nStage plotting for a full program\nOn-the-day coordination (by arrangement)','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(31,3,25,NULL,'Office Function Choreography','office-function-choreography','N/A (Service)','Custom (per event)','On-Location','₹5,999','Starting From','https://images.unsplash.com/photo-1624234636182-6d61fe4cd140?auto=format&fit=crop&w=1400&q=80','Quick-turnaround choreography for office celebrations and team events.','A lighter-scope version of the corporate service, suited to smaller office celebrations rather than large offsites.','A short, accessible group routine\nCompressed rehearsal schedule\nMusic selection guidance\nOn-the-day walkthrough','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(32,3,29,NULL,'Private Function Choreography','private-function-choreography','N/A (Service)','Custom (per event)','On-Location','₹4,499','Starting From','assets/images/gallery/birthday-party.jpg','Choreography for family celebrations, milestone birthdays, and private gatherings.','The most flexible-scope service, tailored individually for family milestones and private celebrations of any size.','A custom routine scaled to your group\nFlexible rehearsal scheduling\nMusic and formation guidance\nOn-the-day support (by arrangement)','active','2026-10-04 08:46:37','2026-10-04 08:46:37');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
DROP TABLE IF EXISTS `site_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_images` (
  `image_key` varchar(60) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`image_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `site_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_images` ENABLE KEYS */;
DROP TABLE IF EXISTS `subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcategories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `slug` varchar(80) NOT NULL,
  `name` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sub` (`category_id`,`slug`),
  CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `subcategories` DISABLE KEYS */;
INSERT INTO `subcategories` VALUES
(1,1,'classical','Classical Dance'),
(2,1,'folk','Folk Dance'),
(3,1,'garba','Garba / Regional Dance'),
(4,1,'bollywood','Bollywood Dance'),
(5,1,'contemporary','Contemporary Dance'),
(6,1,'wedding','Wedding Dance'),
(7,1,'group','Group Dance'),
(8,1,'school','School Dance'),
(9,1,'kids','Kids Dance'),
(10,1,'competition','Competition Dance'),
(11,1,'stage','Stage Performance'),
(12,2,'classical','Classical Singing'),
(13,2,'folk','Folk Singing'),
(14,2,'bollywood','Bollywood Singing'),
(15,2,'group','Group Singing'),
(16,2,'patriotic','Patriotic Singing'),
(17,2,'devotional','Devotional Singing'),
(18,2,'kids','Kids Singing'),
(19,2,'vocal','Vocal Training'),
(20,3,'learn','Learn Choreography'),
(21,3,'wedding','Wedding Choreography'),
(22,3,'school','School Function'),
(23,3,'college','College Function'),
(24,3,'party','Party Function'),
(25,3,'office','Office Function'),
(26,3,'corporate','Corporate Events'),
(27,3,'cultural','Cultural Function'),
(28,3,'annual','Annual Function'),
(29,3,'private','Private Function');
/*!40000 ALTER TABLE `subcategories` ENABLE KEYS */;
DROP TABLE IF EXISTS `tutors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `specialization` varchar(190) NOT NULL DEFAULT '',
  `category` varchar(80) NOT NULL DEFAULT 'dance',
  `intro` varchar(400) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `experience` varchar(80) DEFAULT NULL,
  `qualification` varchar(190) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `instagram` varchar(190) DEFAULT NULL,
  `youtube` varchar(190) DEFAULT NULL,
  `website` varchar(190) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `tutors` DISABLE KEYS */;
INSERT INTO `tutors` VALUES
(1,'Royan Mehta','royan-mehta','Bollywood & Contemporary Dance','dance','Focuses on building performance-ready choreography, from first-timers to competition teams.','Demo Instructor profile. Royan leads the academy\'s Bollywood, contemporary, and choreography-focused courses, with an emphasis on making choreography feel achievable for beginners while still challenging advanced students.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1533993010187-6a08e5a05ec9?auto=format&fit=crop&w=800&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(2,'Dr. Kavya Nair','dr-kavya-nair','Classical Dance (Bharatanatyam)','dance','Structures classical training around a grade-by-grade progression, from adavus to abhinaya.','Demo Instructor profile. Dr. Nair teaches the academy\'s Bharatanatyam foundation and kids\' programs, with a focus on correct fundamentals from the very first class.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1589146343010-b0eb86d21155?auto=format&fit=crop&w=800&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(3,'Meera Iyer','meera-iyer','Classical Dance (Kathak)','dance','Balances technical footwork training with the storytelling side of Kathak.','Demo Instructor profile. Meera teaches Kathak foundations and the academy\'s advanced stage performance training, focusing on expression as much as technique.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1479813183133-f2e9b38ed6c4?auto=format&fit=crop&w=1400&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(4,'Ananya Rao','ananya-rao','Folk & Garba Dance','dance','Brings regional folk traditions into structured, beginner-friendly classes.','Demo Instructor profile. Ananya leads the academy\'s folk, Garba, and group dance performance courses, with a focus on the cultural context behind each style.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1624234636182-6d61fe4cd140?auto=format&fit=crop&w=1400&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(5,'Akash Gupta','akash-gupta','Group Singing & Vocal Training','singing','Runs the academy\'s general vocal training and group singing workshops.','Demo Instructor profile. Akash teaches ongoing vocal training and group singing, focused on building consistent practice habits over flashy quick results.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/images/gallery/band-performance.jpg','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(6,'Nikhil Bansal','nikhil-bansal','Classical & Devotional Singing','singing','Teaches classical vocal foundations alongside devotional (bhajan) repertoire.','Demo Instructor profile. Nikhil teaches the academy\'s classical vocal foundation and devotional singing courses, emphasizing breath and swara fundamentals.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1730875647697-eace28e2a77e?auto=format&fit=crop&w=800&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(7,'Arnav Chatterjee','arnav-chatterjee','Bollywood Singing','singing','Focuses on pitch accuracy and phrasing for contemporary film-song singing.','Demo Instructor profile. Arnav teaches Bollywood vocal training, with a focus on translating raw enthusiasm for singing into technically solid performance.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1763964062626-063ceec3100a?auto=format&fit=crop&w=800&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(8,'Priyanka Sethi','priyanka-sethi','Folk & Patriotic Singing','singing','Leads folk singing and the seasonal patriotic singing program.','Demo Instructor profile. Priyanka teaches folk singing traditions and the academy\'s seasonal patriotic singing program for school and community events.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1767376133991-a3306ad0817f?auto=format&fit=crop&w=800&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(9,'Vidya Krishnan','vidya-krishnan','Kids Vocal Training','singing','Specialises in making singing approachable and fun for young children.','Demo Instructor profile. Vidya teaches the academy\'s kids vocal basics program, prioritising confidence and enjoyment over technical pressure at a young age.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'https://images.unsplash.com/photo-1662397699540-533dd886809d?auto=format&fit=crop&w=800&q=80','active','2026-10-04 08:46:37','2026-10-04 08:46:37'),
(10,'Devansh Oberoi','devansh-oberoi','Stage Singing & Performance','singing','Works with students who already sing well on stage presence and delivery.','Demo Instructor profile. Devansh teaches the academy\'s stage singing preparation course, focused on microphone technique and performance confidence.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/images/gallery/studio-band.jpg','active','2026-10-04 08:46:37','2026-10-04 08:46:37');
/*!40000 ALTER TABLE `tutors` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

