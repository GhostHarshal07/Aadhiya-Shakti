-- ============================================================================
-- Aadhiya Shakti Academy (static site) — Contact Messages
--
-- This is the ONLY database table this project uses. Everything else on
-- the site (courses, instructors, gallery, etc.) stays static, per the
-- original project brief — this table exists solely to store Contact
-- page submissions so they can be viewed in admin/messages.php.
-- ============================================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS contact_messages (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(120) NOT NULL,
  email      VARCHAR(190) NOT NULL,
  phone      VARCHAR(30)  NULL,
  service    VARCHAR(60)  NOT NULL,
  message    TEXT NOT NULL,
  status     ENUM('new','read','archived') NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_contact_messages_status ON contact_messages(status);
CREATE INDEX idx_contact_messages_created ON contact_messages(created_at);
