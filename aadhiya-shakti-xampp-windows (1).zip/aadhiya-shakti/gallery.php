<?php
$page_title = 'Gallery — Aadhiya Shakti Academy';
$page_description = 'Photos from dance, singing, choreography, and workshop sessions at Aadhiya Shakti Academy.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$gallery = get_gallery();
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">A Glimpse Inside</span>
    <h1>Gallery</h1>
    <p>Sample imagery representing dance, singing, and choreography at the academy. Click any photo to view it larger.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="gallery-grid">
      <?php foreach ($gallery as $item): ?>
        <div class="gallery-item" data-lightbox-src="<?= $item['image'] ?>" data-lightbox-alt="<?= htmlspecialchars($item['caption']) ?>">
          <img src="<?= $item['image'] ?>" alt="<?= htmlspecialchars($item['caption']) ?>" loading="lazy">
          <div class="gallery-caption"><?= htmlspecialchars($item['category']) ?> — <?= htmlspecialchars($item['caption']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<div class="lightbox">
  <button class="lightbox-close" aria-label="Close">&times;</button>
  <img src="" alt="">
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
