<?php
$page_title = 'Explore Our Courses — Aadhiya Shakti Academy';
$page_description = 'Discover dance, singing and choreography programs designed for beginners, intermediate learners and advanced performers.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$categories = get_categories();
$courses    = get_courses();
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">All Programs</span>
    <h1>Explore Our Courses</h1>
    <p>Discover dance, singing and choreography programs designed for beginners, intermediate learners and advanced performers.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">

    <div class="search-box">
      <input type="text" data-course-search placeholder="Search courses, instructors, styles...">
    </div>

    <div class="filter-bar" data-filter-bar>
      <button class="filter-btn active" data-value="all">All</button>
      <?php foreach ($categories as $cat): ?>
        <button class="filter-btn" data-value="<?= $cat['slug'] ?>"><?= htmlspecialchars($cat['name']) ?></button>
      <?php endforeach; ?>
    </div>

    <div class="subfilter-bar" data-subfilter-bar style="display:none;">
      <button class="subfilter-btn active" data-value="all" data-parent="all">All</button>
      <?php foreach ($categories as $cat): ?>
        <?php foreach ($cat['subcategories'] as $subSlug => $subName): ?>
          <button class="subfilter-btn" data-value="<?= $subSlug ?>" data-parent="<?= $cat['slug'] ?>" style="display:none;"><?= htmlspecialchars($subName) ?></button>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </div>

    <div class="course-grid">
      <?php foreach ($courses as $slug => $course):
        $tint = $course['category'] === 'dance' ? 'dance' : ($course['category'] === 'singing' ? 'singing' : 'choreo');
        $searchable = strtolower($course['title'] . ' ' . $course['category'] . ' ' . $course['subcategory'] . ' ' . ($course['instructor'] ?? '') . ' ' . $course['excerpt']);
      ?>
        <div class="course-card" data-course-card data-category="<?= $course['category'] ?>" data-subcategory="<?= $course['subcategory'] ?>" data-search="<?= htmlspecialchars($searchable) ?>">
          <div class="img-tint img-tint--<?= $tint ?>">
            <img src="<?= $course['image'] ?>" alt="<?= htmlspecialchars($course['title']) ?> class" loading="lazy">
          </div>
          <div class="course-card-body">
            <div class="course-tags">
              <span class="tag"><?= ucfirst($course['category']) ?></span>
              <span class="tag"><?= htmlspecialchars($categories[$course['category']]['subcategories'][$course['subcategory']] ?? '') ?></span>
            </div>
            <h3><?= htmlspecialchars($course['title']) ?></h3>
            <p class="excerpt"><?= htmlspecialchars($course['excerpt']) ?></p>
            <div class="course-meta-row">
              <span><strong>Level:</strong> <?= htmlspecialchars($course['level']) ?></span>
              <span><strong>Duration:</strong> <?= htmlspecialchars($course['duration']) ?></span>
              <span><strong>Mode:</strong> <?= htmlspecialchars($course['mode']) ?></span>
            </div>
            <div class="course-card-footer">
              <div>
                <span class="course-price"><?= htmlspecialchars($course['price']) ?></span>
                <span class="price-note"><?= htmlspecialchars($course['price_note']) ?></span>
              </div>
              <a href="course-detail.php?course=<?= $slug ?>" class="btn btn-outline btn-sm">View Course</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <p class="no-results">No courses match your search or filters. Try clearing the search box or selecting "All".</p>

  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
