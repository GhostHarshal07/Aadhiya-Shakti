<?php
/**
 * includes/header.php
 * Purely a reusable frontend template fragment. No database, no session
 * logic beyond what's needed for this page's own display state.
 * Expects (optionally) $page_title and $page_description to be set by
 * the including page BEFORE this file is required.
 */

$page_title       = $page_title ?? 'Aadhiya Shakti Academy — Dance, Singing, Music & Choreography';
$page_description = $page_description ?? 'A dance, singing, music and choreography academy offering structured courses and event choreography services.';
$current_page     = basename($_SERVER['SCRIPT_NAME']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8') ?></title>
<meta name="description" content="<?= htmlspecialchars($page_description, ENT_QUOTES, 'UTF-8') ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="assets/images/logo.png">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="site-header">
  <nav class="nav">
    <a href="index.php" class="brand">
      <img src="assets/images/logo.png" alt="Aadhiya Shakti Academy logo" class="brand-logo">
      Aadhiya Shakti Academy
    </a>

    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="<?= $current_page === 'index.php' ? 'active' : '' ?>">Home</a></li>
      <li><a href="about.php" class="<?= $current_page === 'about.php' ? 'active' : '' ?>">About</a></li>
      <li><a href="courses.php" class="<?= $current_page === 'courses.php' || $current_page === 'course-detail.php' ? 'active' : '' ?>">Courses</a></li>
      <li><a href="instructors.php" class="<?= $current_page === 'instructors.php' || $current_page === 'instructor-detail.php' ? 'active' : '' ?>">Instructors</a></li>
      <li><a href="gallery.php" class="<?= $current_page === 'gallery.php' ? 'active' : '' ?>">Gallery</a></li>
      <li><a href="events.php" class="<?= $current_page === 'events.php' ? 'active' : '' ?>">Events</a></li>
      <li><a href="services.php" class="<?= $current_page === 'services.php' ? 'active' : '' ?>">Services</a></li>
      <li><a href="testimonials.php" class="<?= $current_page === 'testimonials.php' ? 'active' : '' ?>">Testimonials</a></li>
      <li><a href="contact.php" class="<?= $current_page === 'contact.php' ? 'active' : '' ?>">Contact</a></li>
    </ul>

    <div class="nav-actions">
      <a href="contact.php" class="btn btn-coral">Contact Us</a>
      <a href="admin/login.php" style="font-size:0.78rem; color:var(--charcoal-soft); font-weight:600; white-space:nowrap;" title="Academy staff login">Admin</a>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">&#9776;</button>
    </div>
  </nav>
</header>
