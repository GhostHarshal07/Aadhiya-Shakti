<?php
$page_title = 'Aadhiya Shakti Academy — Dance, Singing, Music & Choreography';
$page_description = 'A dance, singing, music and choreography academy offering structured courses for all ages plus event choreography services for weddings, schools, and celebrations.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$categories   = get_categories();
$courses      = get_courses();
$featured     = array_slice($courses, 0, 8, true);
$instructors  = array_slice(get_instructors(), 0, 4, true);
$events       = array_slice(get_events(), 0, 3);
$gallery      = array_slice(get_gallery(), 0, 6);
$testimonials = array_slice(get_testimonials(), 0, 3);
?>

<!-- HERO -->
<section class="hero">
  <div class="container hero-grid">
    <div>
      <span class="eyebrow">Dance · Singing · Music · Choreography</span>
      <h1>Aadhiya Shakti Academy</h1>
      <p class="lead">Live online &amp; in-studio music and dance classes. Structured training in classical, folk, and contemporary dance and singing — plus choreography services for weddings, schools, and events.</p>
      <div class="hero-actions">
        <a href="courses.php" class="btn btn-primary">Explore Courses</a>
        <a href="about.php" class="btn btn-outline">Discover Our Academy</a>
      </div>
    </div>
    <div class="hero-art reveal-scale">
      <img src="<?= IMG_BHARATANATYAM ?>" alt="A dancer in a dramatic Bharatanatyam performance pose" loading="eager">
    </div>
  </div>
  <div class="container">
    <div class="hero-art-reflection">
      <img src="<?= IMG_BHARATANATYAM ?>" alt="" aria-hidden="true">
    </div>
  </div>
</section>

<!-- INTRODUCTION -->
<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Who We Are</span>
      <h2>Learning built around craft, not just enrollment</h2>
      <p>Aadhiya Shakti Academy brings together structured dance and singing training with a dedicated choreography service for events — one place for both the years-long practice and the one-night performance.</p>
      <div style="margin-top:24px;"><a href="about.php" class="btn btn-outline btn-sm">Learn More About Us</a></div>
    </div>
  </div>
</section>

<!-- COURSE CATEGORIES -->
<section style="background:var(--paper);">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">What We Teach</span>
      <h2>Three disciplines, one academy</h2>
    </div>
    <div class="category-grid">
      <?php foreach ($categories as $cat): ?>
        <div class="category-card reveal-scale">
          <div class="img-tint img-tint--<?= $cat['slug'] === 'dance' ? 'dance' : ($cat['slug'] === 'singing' ? 'singing' : 'choreo') ?>">
            <img src="<?= $cat['image'] ?>" alt="<?= htmlspecialchars($cat['name']) ?> training at Aadhiya Shakti Academy" loading="lazy">
          </div>
          <div class="category-card-body">
            <span class="category-count"><?= count($cat['subcategories']) ?> Programs</span>
            <h3><?= htmlspecialchars($cat['name']) ?></h3>
            <p><?= htmlspecialchars($cat['blurb']) ?></p>
            <a href="courses.php?category=<?= $cat['slug'] ?>" class="btn btn-coral btn-sm">Explore Courses</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FEATURED COURSES (drag row) -->
<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Featured Programs</span>
      <h2>A sample of what's on offer</h2>
    </div>
    <p class="drag-hint">← Drag to explore courses →</p>
    <div class="drag-row-wrap">
      <div class="drag-row">
        <?php foreach ($featured as $slug => $course): ?>
          <div class="course-card">
            <div class="img-tint img-tint--<?= $course['category'] === 'dance' ? 'dance' : ($course['category'] === 'singing' ? 'singing' : 'choreo') ?>">
              <img src="<?= $course['image'] ?>" alt="<?= htmlspecialchars($course['title']) ?> class" loading="lazy">
            </div>
            <div class="course-card-body">
              <div class="course-tags"><span class="tag"><?= ucfirst($course['category']) ?></span></div>
              <h3><?= htmlspecialchars($course['title']) ?></h3>
              <p class="excerpt"><?= htmlspecialchars($course['excerpt']) ?></p>
              <div class="course-card-footer">
                <div>
                  <span class="course-price"><?= htmlspecialchars($course['price']) ?></span>
                  <span class="price-note"><?= htmlspecialchars($course['price_note']) ?></span>
                </div>
                <a href="course-detail.php?course=<?= $slug ?>" class="btn btn-outline btn-sm">View Course</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div style="text-align:center; margin-top:20px;"><a href="courses.php" class="btn btn-primary">View All Courses</a></div>
  </div>
</section>

<!-- WHY CHOOSE US -->
<section style="background:var(--paper);">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Why Aadhiya Shakti</span>
      <h2>A structured approach to creative learning</h2>
    </div>
    <div class="pillar-grid">
      <div class="pillar reveal"><div class="pillar-icon">1</div><h3 style="font-size:1.05rem;">Structured Learning Approach</h3><p>Clear, level-based progression in every course.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">2</div><h3 style="font-size:1.05rem;">Online &amp; In-Studio Options</h3><p>Learn from home or in person, depending on the course.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">3</div><h3 style="font-size:1.05rem;">Beginner-Friendly Programs</h3><p>Most courses assume no prior experience.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">4</div><h3 style="font-size:1.05rem;">Performance-Focused</h3><p>Real recitals and showcases, not just lessons.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">5</div><h3 style="font-size:1.05rem;">Creative Environment</h3><p>A space to practice, collaborate, and perform.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">6</div><h3 style="font-size:1.05rem;">Cultural &amp; Contemporary Styles</h3><p>From classical tradition to modern movement.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">7</div><h3 style="font-size:1.05rem;">Individual Attention</h3><p>Small groups so instructors can actually adjust pacing.</p></div>
      <div class="pillar reveal"><div class="pillar-icon">8</div><h3 style="font-size:1.05rem;">Event Choreography</h3><p>A dedicated service for weddings, schools, and events.</p></div>
    </div>
  </div>
</section>

<!-- INSTRUCTOR PREVIEW -->
<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Meet The Faculty</span>
      <h2>Instructors across dance and singing</h2>
    </div>
    <div class="instructor-grid">
      <?php foreach ($instructors as $slug => $person): ?>
        <div class="instructor-card reveal-left">
          <div class="img-tint img-tint--<?= $person['category'] === 'dance' ? 'dance' : 'singing' ?>">
            <img src="<?= $person['image'] ?>" alt="Artistic action shot representing <?= htmlspecialchars($person['specialty']) ?>" loading="lazy">
          </div>
          <div class="instructor-card-body">
            <span class="demo-badge">Demo Instructor</span>
            <h3><?= htmlspecialchars($person['name']) ?></h3>
            <div class="specialty"><?= htmlspecialchars($person['specialty']) ?></div>
            <p class="intro"><?= htmlspecialchars($person['intro']) ?></p>
            <a href="instructor-detail.php?instructor=<?= $slug ?>" class="btn btn-outline btn-sm">View Profile</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:28px;"><a href="instructors.php" class="btn btn-outline">All Instructors</a></div>
  </div>
</section>

<!-- UPCOMING EVENTS -->
<section style="background:var(--paper);">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">What's On</span>
      <h2>Upcoming Events</h2>
    </div>
    <div class="event-grid">
      <?php foreach ($events as $event): ?>
        <div class="event-card reveal-right">
          <div class="img-tint img-tint--choreo"><img src="<?= $event['image'] ?>" alt="<?= htmlspecialchars($event['title']) ?>" loading="lazy"></div>
          <div class="event-card-body">
            <span class="event-type"><?= htmlspecialchars($event['type']) ?></span>
            <h3><?= htmlspecialchars($event['title']) ?></h3>
            <p class="event-meta"><?= htmlspecialchars($event['date']) ?> · <?= htmlspecialchars($event['location']) ?></p>
            <p style="font-size:0.9rem; color:var(--charcoal-soft);"><?= htmlspecialchars($event['description']) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:28px;"><a href="events.php" class="btn btn-outline">All Events</a></div>
  </div>
</section>

<!-- GALLERY PREVIEW -->
<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">A Glimpse Inside</span>
      <h2>Gallery</h2>
    </div>
    <div class="gallery-grid">
      <?php foreach ($gallery as $item): ?>
        <div class="gallery-item">
          <img src="<?= $item['image'] ?>" alt="<?= htmlspecialchars($item['caption']) ?>" loading="lazy">
          <div class="gallery-caption"><?= htmlspecialchars($item['caption']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:28px;"><a href="gallery.php" class="btn btn-outline">View Full Gallery</a></div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section style="background:var(--paper);">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Sample Testimonials</span>
      <h2>What learners &amp; clients say</h2>
    </div>
    <div class="testimonial-grid">
      <?php foreach ($testimonials as $t): ?>
        <div class="testimonial-card reveal-scale">
          <div class="stars">★★★★★</div>
          <p class="quote">&ldquo;<?= htmlspecialchars($t['quote']) ?>&rdquo;</p>
          <div class="testimonial-person"><?= htmlspecialchars($t['name']) ?><span><?= htmlspecialchars($t['service']) ?></span></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:28px;"><a href="testimonials.php" class="btn btn-outline">Read More</a></div>
  </div>
</section>

<!-- CTA -->
<section>
  <div class="container">
    <div class="cta-band">
      <h2>Ready to Explore Your Creative Journey?</h2>
      <p>Explore our dance, singing and choreography programs, or contact Aadhiya Shakti Academy to discuss your requirements.</p>
      <div class="cta-actions">
        <a href="courses.php" class="btn btn-coral">Explore Courses</a>
        <a href="contact.php" class="btn btn-outline" style="border-color:var(--ivory); color:var(--ivory);">Contact Us</a>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
