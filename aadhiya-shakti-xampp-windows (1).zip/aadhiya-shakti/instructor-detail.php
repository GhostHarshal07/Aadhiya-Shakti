<?php
require_once __DIR__ . '/includes/data.php';

$slug = isset($_GET['instructor']) ? trim((string) $_GET['instructor']) : '';
$person = $slug !== '' ? get_instructor($slug) : null;

if ($person) {
    $page_title = $person['name'] . ' — Aadhiya Shakti Academy';
    $page_description = $person['intro'];
} else {
    $page_title = 'Instructor Not Found — Aadhiya Shakti Academy';
    $page_description = 'This instructor profile could not be found.';
}
require_once __DIR__ . '/includes/header.php';

if (!$person) {
    ?>
    <section class="page-header">
      <div class="container">
        <h1>We couldn't find that instructor</h1>
        <div style="margin-top:24px;"><a href="instructors.php" class="btn btn-primary">Browse All Instructors</a></div>
      </div>
    </section>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$relatedCourses = array_filter(get_courses(), fn($c) => $c['instructor'] === $slug);
$tint = $person['category'] === 'dance' ? 'dance' : 'singing';
?>

<section class="page-header" style="padding-bottom:0;">
  <div class="container" style="display:grid; grid-template-columns: 300px 1fr; gap:40px; align-items:center; text-align:left; max-width:900px; margin:0 auto;">
    <div class="img-tint img-tint--<?= $tint ?>" style="aspect-ratio:1/1; border-radius:50%;">
      <img src="<?= $person['image'] ?>" alt="Artistic action shot representing <?= htmlspecialchars($person['specialty']) ?>" style="border-radius:50%;">
    </div>
    <div>
      <span class="demo-badge">Demo Instructor</span>
      <h1 style="margin:10px 0 4px;"><?= htmlspecialchars($person['name']) ?></h1>
      <div class="specialty" style="font-size:1rem;"><?= htmlspecialchars($person['specialty']) ?></div>
    </div>
  </div>
</section>

<section>
  <div class="container" style="max-width:900px;">
    <div class="info-note">This is a fictional demo profile created for this project, not a real instructor at any academy.</div>

    <h2>Teaching Focus</h2>
    <p style="margin:14px 0 32px; color:var(--charcoal-soft);"><?= htmlspecialchars($person['bio']) ?></p>

    <?php if (!empty($relatedCourses)): ?>
      <h2>Related Courses</h2>
      <div class="course-grid" style="margin-top:20px;">
        <?php foreach ($relatedCourses as $courseSlug => $course): ?>
          <div class="course-card">
            <div class="img-tint img-tint--<?= $tint ?>"><img src="<?= $course['image'] ?>" alt="<?= htmlspecialchars($course['title']) ?>" loading="lazy"></div>
            <div class="course-card-body">
              <h3><?= htmlspecialchars($course['title']) ?></h3>
              <p class="excerpt"><?= htmlspecialchars($course['excerpt']) ?></p>
              <div class="course-card-footer">
                <span class="course-price"><?= htmlspecialchars($course['price']) ?></span>
                <a href="course-detail.php?course=<?= $courseSlug ?>" class="btn btn-outline btn-sm">View Course</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
