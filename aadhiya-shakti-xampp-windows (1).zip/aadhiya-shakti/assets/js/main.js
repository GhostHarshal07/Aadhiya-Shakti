/**
 * main.js
 * All frontend interactivity for the site. No fetch/XHR to any backend —
 * everything here operates on data already present in the page's HTML.
 */

document.addEventListener('DOMContentLoaded', function () {

  // ---------------- Hero cursor-follow glow ----------------
  var heroSection = document.querySelector('.hero');
  if (heroSection && window.matchMedia('(prefers-reduced-motion: reduce)').matches === false) {
    heroSection.addEventListener('mousemove', function (e) {
      var rect = heroSection.getBoundingClientRect();
      var x = e.clientX - rect.left;
      var y = e.clientY - rect.top;
      heroSection.style.setProperty('--mx', x + 'px');
      heroSection.style.setProperty('--my', y + 'px');
    });
  }

  // ---------------- Mobile nav ----------------
  var navToggle = document.getElementById('navToggle');
  var navLinks  = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () { navLinks.classList.remove('open'); });
    });
  }

  // ---------------- Scroll parallax on hero art ----------------
  var heroArt = document.querySelector('.hero-art img');
  if (heroArt && window.matchMedia('(prefers-reduced-motion: reduce)').matches === false) {
    window.addEventListener('scroll', function () {
      var offset = window.scrollY * 0.15;
      heroArt.style.transform = 'translateY(' + offset + 'px) scale(1.05)';
    }, { passive: true });
  }

  // ---------------- Header shrink/shadow on scroll ----------------
  var siteHeader = document.querySelector('.site-header');
  if (siteHeader) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 40) {
        siteHeader.style.boxShadow = '0 8px 24px rgba(96,29,73,0.12)';
      } else {
        siteHeader.style.boxShadow = 'none';
      }
    }, { passive: true });
  }

  // ---------------- Scroll reveal ----------------
  var revealTargets = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
  if ('IntersectionObserver' in window && revealTargets.length) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach(function (el) { observer.observe(el); });
  } else {
    revealTargets.forEach(function (el) { el.classList.add('is-visible'); });
  }

  // ---------------- Course filters (category + subcategory + search) ----------------
  var filterBar    = document.querySelector('[data-filter-bar]');
  var subfilterBar = document.querySelector('[data-subfilter-bar]');
  var searchInput  = document.querySelector('[data-course-search]');
  var courseCards  = document.querySelectorAll('[data-course-card]');
  var noResults    = document.querySelector('.no-results');

  var activeCategory = 'all';
  var activeSubcategory = 'all';

  function applyFilters() {
    var query = (searchInput ? searchInput.value.trim().toLowerCase() : '');
    var visibleCount = 0;

    courseCards.forEach(function (card) {
      var cat = card.getAttribute('data-category');
      var subcat = card.getAttribute('data-subcategory');
      var haystack = card.getAttribute('data-search') || '';

      var matchesCategory = (activeCategory === 'all' || cat === activeCategory);
      var matchesSubcategory = (activeSubcategory === 'all' || subcat === activeSubcategory);
      var matchesQuery = (query === '' || haystack.indexOf(query) !== -1);

      var visible = matchesCategory && matchesSubcategory && matchesQuery;
      card.style.display = visible ? '' : 'none';
      if (visible) visibleCount++;
    });

    if (noResults) noResults.style.display = visibleCount === 0 ? 'block' : 'none';
  }

  if (filterBar) {
    filterBar.querySelectorAll('.filter-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        filterBar.querySelectorAll('.filter-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        activeCategory = btn.getAttribute('data-value');
        activeSubcategory = 'all';

        // Rebuild subfilter options for the newly selected category
        if (subfilterBar) {
          subfilterBar.querySelectorAll('.subfilter-btn').forEach(function (sb) {
            var sbCat = sb.getAttribute('data-parent');
            sb.style.display = (activeCategory === 'all' || sbCat === activeCategory || sb.getAttribute('data-value') === 'all') ? '' : 'none';
          });
          subfilterBar.querySelectorAll('.subfilter-btn').forEach(function (b) { b.classList.remove('active'); });
          var allBtn = subfilterBar.querySelector('.subfilter-btn[data-value="all"]');
          if (allBtn) allBtn.classList.add('active');
          subfilterBar.style.display = activeCategory === 'all' ? 'none' : 'flex';
        }
        applyFilters();
      });
    });
  }

  if (subfilterBar) {
    subfilterBar.querySelectorAll('.subfilter-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        subfilterBar.querySelectorAll('.subfilter-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        activeSubcategory = btn.getAttribute('data-value');
        applyFilters();
      });
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', applyFilters);
  }

  // Support ?category=slug in the URL to pre-select a filter on load
  (function initFromQueryString() {
    if (!filterBar) return;
    var params = new URLSearchParams(window.location.search);
    var cat = params.get('category');
    if (cat) {
      var targetBtn = filterBar.querySelector('.filter-btn[data-value="' + cat + '"]');
      if (targetBtn) targetBtn.click();
    }
  })();

  // ---------------- Drag / swipe course rows ----------------
  document.querySelectorAll('.drag-row').forEach(function (row) {
    var isDown = false, startX, scrollLeft;

    row.addEventListener('mousedown', function (e) {
      isDown = true;
      row.classList.add('dragging');
      startX = e.pageX - row.offsetLeft;
      scrollLeft = row.scrollLeft;
    });
    ['mouseleave', 'mouseup'].forEach(function (evt) {
      row.addEventListener(evt, function () { isDown = false; row.classList.remove('dragging'); });
    });
    row.addEventListener('mousemove', function (e) {
      if (!isDown) return;
      e.preventDefault();
      var x = e.pageX - row.offsetLeft;
      var walk = (x - startX) * 1.4;
      row.scrollLeft = scrollLeft - walk;
    });
    // Touch scrolling works natively via overflow-x:auto; no JS needed for
    // basic swipe, but we keep momentum smooth via CSS (scroll-snap).
  });

  // ---------------- FAQ accordion ----------------
  document.querySelectorAll('.faq-item').forEach(function (item) {
    var question = item.querySelector('.faq-question');
    var answer = item.querySelector('.faq-answer');
    question.addEventListener('click', function () {
      var isOpen = item.classList.contains('open');
      // Close all others in the same list
      item.parentElement.querySelectorAll('.faq-item').forEach(function (other) {
        other.classList.remove('open');
        other.querySelector('.faq-answer').style.maxHeight = null;
      });
      if (!isOpen) {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });

  // ---------------- Gallery lightbox ----------------
  var lightbox = document.querySelector('.lightbox');
  if (lightbox) {
    var lightboxImg = lightbox.querySelector('img');
    document.querySelectorAll('[data-lightbox-src]').forEach(function (item) {
      item.addEventListener('click', function () {
        lightboxImg.src = item.getAttribute('data-lightbox-src');
        lightboxImg.alt = item.getAttribute('data-lightbox-alt') || '';
        lightbox.classList.add('open');
      });
    });
    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox || e.target.classList.contains('lightbox-close')) {
        lightbox.classList.remove('open');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') lightbox.classList.remove('open');
    });
  }

  // ---------------- Contact form (client-side pre-check only) ----------------
  // Real validation + storage now happens server-side in contact.php.
  // This just catches obvious mistakes before a round-trip to the server,
  // and lets the form submit normally (no preventDefault) once everything
  // looks right.
  var contactForm = document.querySelector('[data-contact-form]');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      var valid = true;

      contactForm.querySelectorAll('[required]').forEach(function (field) {
        var errorEl = field.parentElement.querySelector('.error-text');
        var isEmpty = field.value.trim() === '';
        var isBadEmail = field.type === 'email' && field.value.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim());

        if (isEmpty || isBadEmail) {
          valid = false;
          if (errorEl) {
            errorEl.textContent = isEmpty ? 'This field is required.' : 'Please enter a valid email address.';
            errorEl.style.display = 'block';
          }
          field.style.borderColor = '#601D49';
        } else if (errorEl) {
          errorEl.style.display = 'none';
          field.style.borderColor = '';
        }
      });

      if (!valid) {
        e.preventDefault(); // only block submission when something's actually wrong
      }
      // otherwise: let the form submit normally to contact.php
    });
  }

});
